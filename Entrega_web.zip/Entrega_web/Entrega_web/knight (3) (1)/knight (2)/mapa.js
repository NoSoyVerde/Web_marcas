window.onload = function () {
  var catalunya = new google.maps.LatLng(39.44812, -0.368339);
  var mapOptions = {
    center: catalunya,
    zoom: 8,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
  };
  var mapaCatalunya = new google.maps.Map(
    document.getElementById("mapa"),
    mapOptions
  );
  // Hemos creado el objeto mapaCatalunya
  var marker = new google.maps.Marker({
    position: new google.maps.LatLng(39.44812, -0.368339),
    map: mapaCatalunya,
    title: "CIPFP Ausias March de Valencia",
    icon: "iconos/green.png",
  }); // Hemos creado el objeto marker
  var infowindow = new google.maps.InfoWindow({
    content:
      '<h1>CIPFP Ausias March de Valencia </h1><p>Adreça: Carrer Àngel Villena, s/n , 46013 Valencia.</p><p>Telèfon: 961 20 59 30.</p><img src="ausias.jpg" alt="CIPFP Ausias March de Valencia ">',
  }); // Hemos creado el objeto infowindow
  google.maps.event.addListener(marker, "click", function () {
    infowindow.open(mapaCatalunya, marker);
  }); //Adjuntamos un controlador de eventos para el objeto marker y el evento click.
  var marker1 = new google.maps.Marker({

    
    position: new google.maps.LatLng( 39.44817641340542, -0.3683697323395849),
    map: mapaCatalunya,
  }); //Creamos el objeto marker1
  var infowindow1 = new google.maps.InfoWindow({
    content:
      'Valencia<br/><a href="http://es.wikipedia.org/wiki/Valencia" target="_blank">Wikipedia</a>',
  }); //Creamos el objeto infowindow1
  google.maps.event.addListener(marker1, "click", function () {
    infowindow1.open(mapaCatalunya, marker1);
  }); //Adjuntamos un controlador de eventos para el objeto marker1 y el evento click.
};
